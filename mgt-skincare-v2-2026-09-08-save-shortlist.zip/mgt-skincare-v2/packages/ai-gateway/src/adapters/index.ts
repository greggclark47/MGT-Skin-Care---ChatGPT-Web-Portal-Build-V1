import type { ModelConfig, ProviderName, ProviderResponse } from '../types';

// One adapter interface, four implementations (Section 0.2 row 1: keep Phase 1's adapter
// abstraction — it was the only one of the three routers that had it). Adding a provider is
// a new file here plus a config row; it is never a change to the router or to any caller.
export interface ProviderAdapter {
  readonly name: ProviderName;
  complete(config: ModelConfig, systemPrompt: string, userPrompt: string, signal: AbortSignal): Promise<ProviderResponse>;
}

// Per-million-token pricing, in CENTS, used for cost telemetry and budget enforcement.
//
// The SC-P5 "provider price re-validation" task was carried out on 2026-09-06 and the previous
// [assumption] figures were WRONG in a way that mattered:
//
//   claude-haiku-4-5   was  8 /  40  — actual 100 /  500  (10x too low)
//   claude-sonnet-4-6  was 30 / 150  — actual 300 / 1500  (10x too low)
//
// Both Anthropic rows had been converted from dollars to cents by multiplying by 10 instead of
// 100. The OpenAI rows were correct, which is why the error was not obvious from the shape of
// the table. Because isWithinBudget() compares recorded spend against caps denominated in real
// cents, the effect was not a cosmetic dashboard error: the 25c/day tier1_copy cap was
// permitting roughly $2.50/day of real Anthropic spend per user, ten times the intended
// ceiling, against a stated KPI of <= $0.02/user.
//
// Every row now carries where its number came from and when it was checked, so the next person
// can tell a verified price from an inherited one without re-deriving the whole table.
export interface ModelPrice {
  /** Cents per MILLION input tokens. */
  input_cents: number;
  /** Cents per MILLION output tokens. */
  output_cents: number;
  source: string;
  /** ISO date this figure was last checked against the provider's published pricing. */
  verified_on: string;
  /**
   * Set when the provider no longer lists this model on its current pricing page. The number
   * is the last one we could source; it may still be served as a legacy model, but a build
   * routing production traffic to it is making a decision nobody took deliberately.
   */
  legacy?: true;
}

const ANTHROPIC_PRICING = 'https://platform.claude.com/docs/en/about-claude/pricing';

export const PRICING_PER_MTOK: Record<string, ModelPrice> = {
  // [sourced] $1 / $5 per MTok.
  'claude-haiku-4-5': {
    input_cents: 100, output_cents: 500,
    source: ANTHROPIC_PRICING, verified_on: '2026-09-06',
  },
  // [sourced] $3 / $15 per MTok.
  'claude-sonnet-4-6': {
    input_cents: 300, output_cents: 1500,
    source: ANTHROPIC_PRICING, verified_on: '2026-09-06',
  },
  // [sourced] $2 / $10 per MTok. Not currently referenced by the task registry, listed so the
  // cheaper-than-4.6 option is visible when task assignments are next revisited.
  'claude-sonnet-5': {
    input_cents: 200, output_cents: 1000,
    source: ANTHROPIC_PRICING, verified_on: '2026-09-06',
  },
  // [sourced] $0.30 / $2.50 per MTok. The current Flash-Lite; see the note on
  // gemini-2-flash-lite below.
  'gemini-3-5-flash-lite': {
    input_cents: 30, output_cents: 250,
    source: 'https://ai.google.dev/gemini-api/docs/pricing', verified_on: '2026-09-06',
  },

  // ---- Legacy: still referenced by task-registry.ts, no longer on the provider's pricing page.
  // Prices below are the last sourced figures and were correct when written; they are NOT
  // re-verifiable as of 2026-09-06. Re-pointing these tasks is a product decision (conflict C2
  // locked provider assignments per task), so the registry is deliberately left alone here.
  'gpt-4o-mini': {
    input_cents: 15, output_cents: 60,
    source: 'OpenAI pricing (gpt-4o-mini no longer listed on the current pricing page)',
    verified_on: '2026-09-06', legacy: true,
  },
  'gemini-2-flash-lite': {
    input_cents: 4, output_cents: 15,
    source: 'Google AI pricing (Gemini 2.0 Flash-Lite no longer listed; current Flash-Lite is 3.5)',
    verified_on: '2026-09-06', legacy: true,
  },
  'text-embedding-3-small': {
    input_cents: 2, output_cents: 0,
    source: 'OpenAI pricing (not listed on the current pricing page)',
    verified_on: '2026-09-06', legacy: true,
  },
};

export function estimateCostCents(model: string, inputTokens: number, outputTokens: number): number {
  const pricing = PRICING_PER_MTOK[model];
  if (!pricing) return 0; // unknown model — cost shows as 0 rather than a fabricated number; the dashboard surfaces it as unpriced
  return (inputTokens / 1_000_000) * pricing.input_cents + (outputTokens / 1_000_000) * pricing.output_cents;
}

/**
 * Models whose price could not be re-verified against a live provider pricing page. Surface
 * this on the AI-economics dashboard: a cost figure derived from an unverifiable price is an
 * estimate wearing a number's clothing.
 */
export function legacyPricedModels(): string[] {
  return Object.entries(PRICING_PER_MTOK).filter(([, p]) => p.legacy).map(([m]) => m).sort();
}
