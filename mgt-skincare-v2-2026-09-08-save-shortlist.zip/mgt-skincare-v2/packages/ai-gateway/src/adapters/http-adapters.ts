import type { ModelConfig, ProviderName, ProviderResponse } from '../types';
import type { ProviderAdapter } from './index';

// HTTP transport is injected so adapters are testable without network access and so the
// API key source stays the caller's concern (env in prod, fixture in tests).
export type HttpPost = (url: string, headers: Record<string, string>, body: unknown, signal: AbortSignal) => Promise<any>;

export const defaultHttpPost: HttpPost = async (url, headers, body, signal) => {
  const res = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json', ...headers }, body: JSON.stringify(body), signal });
  if (!res.ok) throw new Error(`provider_http_${res.status}`);
  return res.json();
};

export class AnthropicAdapter implements ProviderAdapter {
  readonly name: ProviderName = 'anthropic';
  constructor(private apiKey: string, private post: HttpPost = defaultHttpPost) {}
  async complete(config: ModelConfig, systemPrompt: string, userPrompt: string, signal: AbortSignal): Promise<ProviderResponse> {
    const json = await this.post('https://api.anthropic.com/v1/messages', {
      'x-api-key': this.apiKey, 'anthropic-version': '2023-06-01',
    }, {
      model: config.model, max_tokens: config.max_tokens, temperature: config.temperature,
      system: systemPrompt, messages: [{ role: 'user', content: userPrompt }],
    }, signal);
    return {
      text: json.content?.[0]?.text ?? '',
      input_tokens: json.usage?.input_tokens ?? 0,
      output_tokens: json.usage?.output_tokens ?? 0,
      model: config.model, provider: this.name,
    };
  }
}

export class OpenAiAdapter implements ProviderAdapter {
  readonly name: ProviderName;
  constructor(private apiKey: string, private baseUrl = 'https://api.openai.com/v1', private post: HttpPost = defaultHttpPost, name: ProviderName = 'openai') {
    this.name = name;
  }
  async complete(config: ModelConfig, systemPrompt: string, userPrompt: string, signal: AbortSignal): Promise<ProviderResponse> {
    const json = await this.post(`${this.baseUrl}/chat/completions`, {
      authorization: `Bearer ${this.apiKey}`,
    }, {
      model: config.model, max_tokens: config.max_tokens, temperature: config.temperature,
      messages: [{ role: 'system', content: systemPrompt }, { role: 'user', content: userPrompt }],
    }, signal);
    return {
      text: json.choices?.[0]?.message?.content ?? '',
      input_tokens: json.usage?.prompt_tokens ?? 0,
      output_tokens: json.usage?.completion_tokens ?? 0,
      model: config.model, provider: this.name,
    };
  }
}

export class GeminiAdapter implements ProviderAdapter {
  readonly name: ProviderName = 'gemini';
  constructor(private apiKey: string, private post: HttpPost = defaultHttpPost) {}
  async complete(config: ModelConfig, systemPrompt: string, userPrompt: string, signal: AbortSignal): Promise<ProviderResponse> {
    const json = await this.post(
      `https://generativelanguage.googleapis.com/v1beta/models/${config.model}:generateContent?key=${this.apiKey}`,
      {},
      {
        systemInstruction: { parts: [{ text: systemPrompt }] },
        contents: [{ role: 'user', parts: [{ text: userPrompt }] }],
        generationConfig: { maxOutputTokens: config.max_tokens, temperature: config.temperature },
      },
      signal,
    );
    return {
      text: json.candidates?.[0]?.content?.parts?.[0]?.text ?? '',
      input_tokens: json.usageMetadata?.promptTokenCount ?? 0,
      output_tokens: json.usageMetadata?.candidatesTokenCount ?? 0,
      model: config.model, provider: this.name,
    };
  }
}
