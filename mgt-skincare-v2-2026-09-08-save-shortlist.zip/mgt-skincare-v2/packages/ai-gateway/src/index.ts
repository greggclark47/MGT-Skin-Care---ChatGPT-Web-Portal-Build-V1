// @mgt/ai-gateway — provider-agnostic AI routing layer (Section E.2-E.5).
// task classifier -> router -> provider adapter -> validator -> structured response
// TODO(SC-P1/P2): implement task registry, provider adapters (Anthropic/OpenAI/Gemini/OpenAI-compatible),
// retry/timeout/fallback chain, circuit breaker, per-user budgets, llm_routing_log telemetry.
export const AI_GATEWAY_VERSION = '0.1.0-stub';
