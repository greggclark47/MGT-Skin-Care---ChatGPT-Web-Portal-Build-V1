import type { TaskConfig, TaskType } from './types';

// The fixed task registry (Section E.3). Default provider assignments follow conflict C2's
// resolution: Haiku for Tier-1 copy (Phase 10's safety work is tuned to it), Gemini
// Flash-Lite for vision (Phase 3, working, cheapest), Sonnet for Tier-3 premium, OpenAI
// text-embedding-3-small for embeddings. Every one of these is a CONFIG value, not code —
// swapping a provider per task is a row change, which is the whole point of C2.

const HAIKU = { provider: 'anthropic' as const, model: 'claude-haiku-4-5', max_tokens: 700, temperature: 0.4 };
const SONNET = { provider: 'anthropic' as const, model: 'claude-sonnet-4-6', max_tokens: 2000, temperature: 0.5 };
const GPT_MINI = { provider: 'openai' as const, model: 'gpt-4o-mini', max_tokens: 700, temperature: 0.4 };
const FLASH_LITE = { provider: 'gemini' as const, model: 'gemini-2-flash-lite', max_tokens: 700, temperature: 0.3 };

function tier1(task_type: TaskType, prompt_version: string, grounded: boolean, schema?: TaskConfig['response_schema']): TaskConfig {
  return {
    task_type, primary: HAIKU, fallbacks: [GPT_MINI, FLASH_LITE],
    budget_class: 'tier1_copy', requires_entitlement: false,
    prompt_version, timeout_ms: 8000, grounded, response_schema: schema,
  };
}

export const TASK_REGISTRY: Record<TaskType, TaskConfig> = {
  routine_narrative: tier1('routine_narrative', 'v2.0.0', true, {
    type: 'object', required: ['narrative'], properties: { narrative: { type: 'string' }, cited_knowledge_ids: { type: 'array' } },
  }),
  product_why: tier1('product_why', 'v2.0.0', true, {
    type: 'object', required: ['blurb'], properties: { blurb: { type: 'string' }, cited_knowledge_ids: { type: 'array' } },
  }),
  ingredient_tip: tier1('ingredient_tip', 'v2.0.0', true),
  coach_answer: tier1('coach_answer', 'v2.0.0', true),

  // Intent classification for free-text coach messages. Note this only PICKS an intent —
  // the routine mutation itself runs in @mgt/domain's deterministic engines, never here
  // (Section C.4, and the "0 model-authored routine changes" KPI depends on it).
  coach_routine_command: {
    task_type: 'coach_routine_command', primary: HAIKU, fallbacks: [GPT_MINI],
    budget_class: 'tier1_copy', requires_entitlement: false,
    prompt_version: 'v2.0.0', timeout_ms: 5000, grounded: false,
    response_schema: { type: 'object', required: ['intent'], properties: { intent: { type: 'string' }, days: { type: 'number' }, target_delta_cents: { type: 'number' } } },
  },
  classify_intent: { ...tier1('classify_intent', 'v2.0.0', false), timeout_ms: 4000 },
  shopping_assistant: tier1('shopping_assistant', 'v2.0.0', true),
  support_draft: tier1('support_draft', 'v2.0.0', false),
  summarize_conversation: tier1('summarize_conversation', 'v2.0.0', false),

  vision_attributes: {
    task_type: 'vision_attributes', primary: FLASH_LITE, fallbacks: [],
    budget_class: 'tier2_vision', requires_entitlement: false,
    prompt_version: 'v2.0.0', timeout_ms: 15000, grounded: false,
    response_schema: { type: 'object', required: ['attributes'], properties: { attributes: { type: 'object' } } },
  },

  // Tier-3: entitlement-gated. Conflict C13 — Phase 10 documented requirePremium but never
  // enforced it; the router enforces it here and fails CLOSED.
  premium_consultation: {
    task_type: 'premium_consultation', primary: SONNET, fallbacks: [],
    budget_class: 'tier3_premium', requires_entitlement: true,
    prompt_version: 'v2.0.0', timeout_ms: 30000, grounded: true,
  },
  routine_optimization_deep: {
    task_type: 'routine_optimization_deep', primary: SONNET, fallbacks: [],
    budget_class: 'tier3_premium', requires_entitlement: true,
    prompt_version: 'v2.0.0', timeout_ms: 30000, grounded: true,
  },

  embed: {
    task_type: 'embed', primary: { provider: 'openai', model: 'text-embedding-3-small', max_tokens: 0, temperature: 0 },
    fallbacks: [], budget_class: 'embedding', requires_entitlement: false,
    prompt_version: 'v1.0.0', timeout_ms: 10000, grounded: false,
  },
};

export function getTaskConfig(taskType: TaskType): TaskConfig {
  const config = TASK_REGISTRY[taskType];
  if (!config) throw new Error(`unknown_task_type:${taskType}`);
  return config;
}
