const {spawnSync}=require('node:child_process');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const pnpm=process.env.npm_execpath;
if(!pnpm){console.error('Run pnpm verify:release from the project root.');process.exit(1);}
const steps=[
 ...['domain','shared'].map(p=>[p+' build',[pnpm,'--filter','@mgt/'+p,'build']]),
 ['AI gateway typecheck',[pnpm,'--filter','@mgt/ai-gateway','typecheck']],
 ['API build',[pnpm,'--filter','@mgt/api','build']],
 ['Web production build',[pnpm,'--filter','@mgt/web','build']],
 ...['portal','billing','coach','style','admin-access','maintenance'].map(p=>[p+' API suite',['apps/api/test/'+p+'.cjs']]),
 ...['packages/domain/src/__smoke__/pipeline.ts','packages/ai-gateway/src/__smoke__/gateway.ts','packages/ai-gateway/src/__smoke__/pricing.ts','apps/web/src/__smoke__/render.tsx','apps/web/src/__smoke__/admin-render.tsx','apps/web/src/__smoke__/shop-state.ts','apps/web/src/__smoke__/hub-client.cjs'].map(p=>[p,['scripts/run-typescript.cjs',p]])
];
for(const [name,args] of steps){
 console.log('\nCHECK: '+name);
 const result=spawnSync(process.execPath,args,{cwd:root,stdio:'inherit',env:{...process.env,NEXT_TELEMETRY_DISABLED:'1'}});
 if(result.error||result.status!==0){console.error('Release verification failed: '+name);if(result.error)console.error(result.error.message);process.exit(result.status||1);}
}
console.log('\nLocal release verification passed: five build/type checks and thirteen suites. Live services, containers, browser E2E and production operations require separate gates.');
