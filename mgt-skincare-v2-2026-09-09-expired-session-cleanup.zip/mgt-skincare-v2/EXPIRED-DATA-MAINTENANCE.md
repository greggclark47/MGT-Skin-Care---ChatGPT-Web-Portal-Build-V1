# Expired session data maintenance
September 9, 2026 checkpoint.

## Operator flow
In Portal operations, a superadmin or compliance operator can choose **Preview expired data**. The preview reports up to 500 expired sessions and 500 expired request-limit records. It returns counts without session identifiers, tokens or customer details. Previewing does not delete those records.

**Remove previewed records** opens a confirmation dialog describing the selected counts and irreversible removal. The API requires the operator's authenticated session, allowed role, request origin, CSRF token, explicit confirmation and an operator-bound preview token.

A preview lasts 10 minutes. Creating another preview invalidates that operator's earlier one. Cleanup processes only the previewed IDs and rechecks their expiry value inside the deletion transaction. Renewed records, active sessions, records that were not in the preview, accounts, profiles, support requests and deletion requests are preserved. Successful cleanup consumes the preview and writes an audit record with removed counts. A failed audit write rolls back the deletion. After a connection error the UI requires another preview instead of automatically repeating a removal.

## API
- POST /api/hub/admin/maintenance/preview with an empty object.
- POST /api/hub/admin/maintenance/cleanup with preview_token and confirm=true.
- Both require superadmin or compliance. Content-only roles and customers cannot preview or execute cleanup.

## Validation
pnpm verify:release passed: five build/type checks and thirteen suites. The maintenance integration suite covers bounded selection, malformed/boundary expiry values, guest/customer/content-role denial, confirmation, CSRF, origin, preview ownership, refresh/expiry, renewed/unpreviewed records, preserved customer data, audit rollback and revoked access. Tests use isolated in-memory SQLite records, not live customer data.

## Production boundary
This is manual session/request-limit cleanup, not account deletion or a complete retention policy. Account erasure, external-provider cleanup and scheduled retention remain outstanding. Selection currently scans the relevant scopes before bounding the deletion batch; production PostgreSQL load testing and indexed selection are required before large datasets. PostgreSQL and browser interaction testing have not been performed in this checkpoint.

The existing presentation and production-status report describe the preceding readiness audit. This checkpoint advances one part of that backlog and does not establish a production launch or change the conditional timeline.
