'use client';
import React,{useState} from 'react';
import {hub} from '../lib/hub';
import {ConfirmDialog} from './ConfirmDialog';

type Preview={preview_token:string;expires_at:string;counts:{sessions:number;rate:number};has_more:boolean};
export function ExpiredDataCleanup(){
 const [preview,setPreview]=useState<Preview|null>(null),[busy,setBusy]=useState(false),[confirming,setConfirming]=useState(false),[error,setError]=useState(''),[message,setMessage]=useState('');
 async function inspect(){
  setBusy(true);setError('');setMessage('');setPreview(null);
  try{setPreview(await hub('/admin/maintenance/preview',{}));}catch(e){setError((e as Error).message);}finally{setBusy(false);}
 }
 async function clean(){
  if(!preview)return;
  setBusy(true);setError('');
  try{
   const result=await hub('/admin/maintenance/cleanup',{preview_token:preview.preview_token,confirm:true});
   setMessage('Removed '+result.removed.sessions+' expired sessions and '+result.removed.rate+' expired request-limit records.');
  }catch(e){setError((e as Error).message+' Preview again to check the current totals.');}
  finally{setPreview(null);setConfirming(false);setBusy(false);}
 }
 const total=preview?preview.counts.sessions+preview.counts.rate:0;
 return <section className="panel"><h2>Expired session data</h2>
  <p>Review expired sessions and request-limit records before removing them. This cleanup does not remove accounts, profiles, support requests or active sessions.</p>
  {error&&<p role="alert" className="notice error">{error}</p>}
  {message&&<p role="status" className="notice success">{message}</p>}
  <button className="button" disabled={busy} onClick={()=>void inspect()}>{busy&&!confirming?'Checking…':'Preview expired data'}</button>
  {preview&&<div aria-live="polite"><dl className="profile-details"><div><dt>Expired sessions</dt><dd>{preview.counts.sessions}</dd></div><div><dt>Expired request-limit records</dt><dd>{preview.counts.rate}</dd></div></dl>
   <p>{total?'This preview is valid for 10 minutes. Records are checked again before removal.':'No expired records are ready for removal.'}</p>
   {preview.has_more&&<p className="notice">This batch includes up to 500 records of each type. Preview again after cleanup to review the next batch.</p>}
   {total>0&&<button className="button" disabled={busy} onClick={()=>setConfirming(true)}>Remove previewed records</button>}
  </div>}
  <ConfirmDialog open={confirming} title="Remove expired session data?" busy={busy} onCancel={()=>setConfirming(false)} onConfirm={()=>void clean()} confirmLabel="Remove expired records">
   <p>Remove up to {preview?.counts.sessions||0} expired sessions and {preview?.counts.rate||0} expired request-limit records from this preview? Removal cannot be undone. Records renewed since the preview will be kept.</p>
  </ConfirmDialog>
 </section>;
}
