import type {Express} from 'express';
import {randomUUID} from 'node:crypto';
import {check,hash,role,token,wrap} from './security';
import type {Records,Store} from './store';

const LIMIT=500,PLAN_TTL=10*60*1000;
type Candidate={id:string;expires:number};
type Plan={token_hash:string;expires:number;cutoff:number;sessions:Candidate[];rate:Candidate[]};
const expired=(value:unknown,cutoff:number):value is number=>typeof value==='number'&&Number.isFinite(value)&&value>0&&value<cutoff;
export async function cleanupCandidates(r:Records,cutoff:number){
 const select=async(scope:string,field:string)=>{
  const rows=(await r.list(scope)).filter(x=>typeof x?.id==='string'&&x.id.length>0&&expired(x[field],cutoff));
  return {items:rows.slice(0,LIMIT).map(x=>({id:x.id,expires:x[field]})),has_more:rows.length>LIMIT};
 };
 return {sessions:await select('sessions','expires'),rate:await select('rate','reset')};
}
export function installMaintenance(app:Express,db:Store){
 app.post('/api/hub/admin/maintenance/preview',wrap(async(req,res)=>{
  const user=role(req,['superadmin','compliance']),secret=token();
  const result=await db.tx(async r=>{
   const cutoff=Date.now(),selected=await cleanupCandidates(r,cutoff);
   const plan:Plan={token_hash:hash(secret),expires:cutoff+PLAN_TTL,cutoff,sessions:selected.sessions.items,rate:selected.rate.items};
   // One preview per operator. A new preview invalidates that operator's previous confirmation.
   await r.put('maintenance_plans',user.id,plan);
   return {preview_token:secret,expires_at:new Date(plan.expires).toISOString(),cutoff:new Date(cutoff).toISOString(),
    counts:{sessions:plan.sessions.length,rate:plan.rate.length},has_more:selected.sessions.has_more||selected.rate.has_more};
  });
  res.json(result);
 }));
 app.post('/api/hub/admin/maintenance/cleanup',wrap(async(req,res)=>{
  const user=role(req,['superadmin','compliance']);
  check(req.body?.confirm===true,400,'confirm_required','Confirm the expired-data cleanup.');
  check(typeof req.body.preview_token==='string'&&/^[a-f0-9]{64}$/.test(req.body.preview_token),400,'preview_required','Preview the expired data first.');
  const result=await db.tx(async r=>{
   const plan=await r.get<Plan>('maintenance_plans',user.id);
   check(plan&&plan.expires>Date.now()&&plan.token_hash===hash(req.body.preview_token),409,'preview_expired','This preview has expired or changed. Preview the expired data again.');
   const removed={sessions:0,rate:0};
   for(const [scope,field] of [['sessions','expires'],['rate','reset']] as const){
    for(const candidate of plan[scope]){
     const current=await r.get(scope,candidate.id);
     // Re-check under the same transaction. Renewed and newly expired records are preserved.
     if(current&&current[field]===candidate.expires&&expired(current[field],plan.cutoff)){
      await r.remove(scope,candidate.id);removed[scope]++;
     }
    }
   }
   await r.remove('maintenance_plans',user.id);
   const id=randomUUID();
   await r.put('audit',id,{id,actor:user.id,action:'maintenance.expired_data_cleaned',target:'sessions_and_rate',at:new Date().toISOString(),removed});
   return {removed};
  });
  res.json(result);
 }));
}
