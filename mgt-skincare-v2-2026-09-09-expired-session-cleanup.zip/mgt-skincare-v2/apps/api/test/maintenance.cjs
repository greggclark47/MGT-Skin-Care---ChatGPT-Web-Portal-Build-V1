const assert=require('node:assert/strict');
const {createPortal}=require('../dist/portal/server');
const {LocalStore}=require('../dist/portal/store');
const {cleanupCandidates}=require('../dist/portal/maintenance');
(async()=>{
 const bounds=new LocalStore(':memory:');
 try{
  await bounds.tx(async r=>{
   for(let i=0;i<503;i++)await r.put('rate','r'+i,{id:'r'+i,reset:10});
   for(const [id,expires] of [['exact',100],['future',101],['bad','10'],['missing',null]])await r.put('sessions',id,{id,expires});
   const selected=await cleanupCandidates(r,100);
   assert.equal(selected.rate.items.length,500);assert.equal(selected.rate.has_more,true);assert.equal(selected.sessions.items.length,0);
  });
 }finally{await bounds.close();}
 const db=new LocalStore(':memory:');let failAudit=false;
 const store={kind:db.kind,close:()=>db.close(),tx:fn=>db.tx(r=>fn({...r,put:async(scope,id,value)=>{if(failAudit&&scope==='audit')throw Error('test audit outage');return r.put(scope,id,value);}}))};
 const app=await createPortal({store,env:{NODE_ENV:'test',DEMO_MODE:'false',PUBLIC_ORIGIN:'http://localhost:3000'},verifyOtp:async email=>({id:email,email})});
 const server=app.listen(0,'127.0.0.1');await new Promise(r=>server.once('listening',r));
 function client(){let cookie='',csrf='';return async(path,body,extra={})=>{
  const res=await fetch('http://127.0.0.1:'+server.address().port+'/api/hub'+path,{method:body===undefined?'GET':'POST',headers:{cookie,origin:'http://localhost:3000','content-type':'application/json','x-csrf-token':csrf,...extra},body:body===undefined?undefined:JSON.stringify(body)});
  if(res.headers.get('set-cookie'))cookie=res.headers.get('set-cookie').split(';')[0];
  const data=await res.json();if(data.csrf)csrf=data.csrf;return {status:res.status,data};
 };}
 const previewPath='/admin/maintenance/preview',cleanPath='/admin/maintenance/cleanup';
 async function operator(email,roles){
  await db.tx(r=>r.put('accounts',email,{id:email,email,roles}));
  const c=client();await c('/session');await c('/auth/verify',{email,code:'123456'});await c('/session');return c;
 }
 try{
  const guest=client();await guest('/session');
  assert.equal((await guest(previewPath,{})).status,401);
  assert.equal((await guest(cleanPath,{confirm:true})).status,401);
  for(const roles of [[],['viewer'],['catalog_editor'],['sme']]){
   const c=await operator((roles[0]||'customer')+'@test.example',roles);
   assert.equal((await c(previewPath,{}, {'x-role':'superadmin'})).status,403);
   assert.equal((await c(cleanPath,{confirm:true})).status,403);
  }
  const a=await operator('operator@test.example',['compliance']),b=await operator('other@test.example',['superadmin']);
  const old=Date.now()-10000,future=Date.now()+3600000;
  await db.tx(async r=>{
   for(const id of ['s-remove','s-renew'])await r.put('sessions',id,{id,expires:old});
   for(const id of ['r-remove','r-renew'])await r.put('rate',id,{id,reset:old});
   await r.put('sessions','s-active',{id:'s-active',expires:future});
   await r.put('profiles','keep-profile',{important:'kept'});
   await r.put('deletion_requests','keep-request',{status:'pending'});
  });
  assert.equal((await a(previewPath,{}, {'x-csrf-token':'wrong'})).status,403);
  assert.equal((await a(previewPath,{}, {origin:'https://wrong.example'})).status,403);
  const preview=(await a(previewPath,{})).data;
  assert.deepEqual(preview.counts,{sessions:2,rate:2});
  assert(!JSON.stringify(preview).includes('s-remove'),'Preview exposes counts, not record IDs');
  assert(await db.tx(r=>r.get('sessions','s-remove')),'Preview does not delete records');
  assert.equal((await b(cleanPath,{confirm:true,preview_token:preview.preview_token})).status,409);
  assert.equal((await a(cleanPath,{confirm:false,preview_token:preview.preview_token})).status,400);
  assert.equal((await a(cleanPath,{confirm:true})).status,400);
  assert.equal((await a(cleanPath,{confirm:true,preview_token:preview.preview_token},{'x-csrf-token':'bad'})).status,403);
  assert.equal((await a(cleanPath,{confirm:true,preview_token:preview.preview_token},{origin:'https://wrong.example'})).status,403);
  await db.tx(async r=>{
   await r.put('sessions','s-renew',{id:'s-renew',expires:future});
   await r.put('rate','r-renew',{id:'r-renew',reset:future});
   await r.put('sessions','s-later',{id:'s-later',expires:old});
  });
  const done=await a(cleanPath,{confirm:true,preview_token:preview.preview_token});
  assert.equal(done.status,200);assert.deepEqual(done.data.removed,{sessions:1,rate:1});
  await db.tx(async r=>{
   assert.equal(await r.get('sessions','s-remove'),undefined);assert.equal(await r.get('rate','r-remove'),undefined);
   for(const id of ['s-active','s-renew','s-later'])assert(await r.get('sessions',id));
   assert(await r.get('rate','r-renew'));assert(await r.get('profiles','keep-profile'));assert(await r.get('deletion_requests','keep-request'));
   assert((await r.list('audit')).some(x=>x.action==='maintenance.expired_data_cleaned'&&x.removed.sessions===1));
  });
  assert.equal((await a(cleanPath,{confirm:true,preview_token:preview.preview_token})).status,409);
  const first=(await a(previewPath,{})).data;
  const second=(await a(previewPath,{})).data;
  assert.equal((await a(cleanPath,{confirm:true,preview_token:first.preview_token})).status,409);
  await db.tx(async r=>{const p=await r.get('maintenance_plans','operator@test.example');p.expires=Date.now()-1;await r.put('maintenance_plans','operator@test.example',p);});
  assert.equal((await a(cleanPath,{confirm:true,preview_token:second.preview_token})).status,409);
  const rollback=(await a(previewPath,{})).data;failAudit=true;
  assert.equal((await a(cleanPath,{confirm:true,preview_token:rollback.preview_token})).status,500);
  assert(await db.tx(r=>r.get('sessions','s-later')),'Deletion rolls back when audit fails');
  failAudit=false;
  assert.equal((await a(cleanPath,{confirm:true,preview_token:rollback.preview_token})).status,200);
  const revoked=(await a(previewPath,{})).data;
  await db.tx(r=>r.put('accounts','operator@test.example',{id:'operator@test.example',email:'operator@test.example',roles:['viewer']}));
  assert.equal((await a(cleanPath,{confirm:true,preview_token:revoked.preview_token})).status,403);
  console.log('Maintenance checks passed: bounded selection, access, confirmation, CSRF/origin, preview ownership/expiry, renewed and unpreviewed records, preserved customer data, audit rollback and revoked access.');
 }finally{await new Promise(r=>server.close(r));await db.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
