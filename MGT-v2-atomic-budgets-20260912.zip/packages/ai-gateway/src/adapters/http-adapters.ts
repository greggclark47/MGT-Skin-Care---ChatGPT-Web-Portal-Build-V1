import type { ModelConfig, ProviderName, ProviderResponse } from '../types';
import type { ProviderAdapter } from './index';

// HTTP transport is injected so adapters are testable without network access and so the
// API key source stays the caller's concern (env in prod, fixture in tests).
export type HttpPost = (url: string, headers: Record<string, string>, body: unknown, signal: AbortSignal) => Promise<any>;

export const defaultHttpPost: HttpPost = async (url, headers, body, signal) => {
  const res = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json', ...headers }, body: JSON.stringify(body), signal });
  if (!res.ok) throw new Error(`provider_http_${res.status}`);
  return res.json();
};

export class OpenAiAdapter implements ProviderAdapter {
  readonly name: ProviderName;
  constructor(private apiKey: string, private baseUrl = 'https://api.openai.com/v1', private post: HttpPost = defaultHttpPost, name: ProviderName = 'openai') {
    this.name = name;
  }
  async complete(config: ModelConfig, systemPrompt: string, userPrompt: string, signal: AbortSignal): Promise<ProviderResponse> {
    const json = await this.post(`${this.baseUrl}/chat/completions`, {
      authorization: `Bearer ${this.apiKey}`,
    }, {
      model: config.model, max_tokens: config.max_tokens, temperature: config.temperature,
      messages: [{ role: 'system', content: systemPrompt }, { role: 'user', content: userPrompt }],
    }, signal);
    return {
      text: json.choices?.[0]?.message?.content ?? '',
      input_tokens: json.usage?.prompt_tokens ?? 0,
      output_tokens: json.usage?.completion_tokens ?? 0,
      model: config.model, provider: this.name,
    };
  }
}

export class OllamaAdapter implements ProviderAdapter {
  readonly name: ProviderName = 'ollama';
  constructor(private baseUrl = 'http://127.0.0.1:11434', private post: HttpPost = defaultHttpPost) {}
  async complete(config: ModelConfig, systemPrompt: string, userPrompt: string, signal: AbortSignal): Promise<ProviderResponse> {
    const json = await this.post(`${this.baseUrl.replace(/\/$/, '')}/api/chat`, {},
      {
        model: config.model,
        messages: [{ role: 'system', content: systemPrompt }, { role: 'user', content: userPrompt }],
        stream: false,
        keep_alive: '10m',
        options: { num_predict: config.max_tokens, temperature: config.temperature },
      },
      signal,
    );
    return {
      text: json.message?.content ?? json.response ?? '',
      input_tokens: json.prompt_eval_count ?? 0,
      output_tokens: json.eval_count ?? 0,
      model: config.model, provider: this.name,
    };
  }
}

// OpenClaw is an optional OpenAI-compatible orchestration endpoint. By default it points at
// Ollama's /v1 surface, so enabling it does not introduce a second paid provider.
export class OpenClawAdapter extends OpenAiAdapter {
  constructor(baseUrl = 'http://127.0.0.1:11434/v1', apiKey = 'ollama', post: HttpPost = defaultHttpPost) {
    super(apiKey, baseUrl, post, 'openclaw');
  }
}
