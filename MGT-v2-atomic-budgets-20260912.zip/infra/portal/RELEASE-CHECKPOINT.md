# AI release controls checkpoint

2026-09-12 reservation checkpoint: gateway build/regressions/release controls, API build, budget tests, portal/billing/operations tests, and web type checking passed. The local Ollama tags endpoint responded with zero installed models. DATABASE_URL, SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, and OPENAI_API_KEY were absent from the execution environment; no live database or hosted inference test was performed.

Hosted inference now requires an identified account and server-provided premium entitlement on every hosted candidate, including routine-task fallbacks. Budgets are rechecked before each attempt. Accounting or telemetry failures after inference propagate without repeating the provider call.

The admin dashboard converts stored cents into dollars and labels its counts as telemetry records: validation rejections can produce multiple records for one request. These counts are not unique request totals. Token estimates exclude local hardware and hosting costs.

Validated locally: compiled gateway release-control tests, gateway regressions, API build and referral integration tests, and web type checking.

Hosted attempts now reserve estimated cost atomically before calling the provider. Persistent reservations and spend updates share a transaction and a per-budget PostgreSQL advisory lock. Settlement is idempotent and uses the original UTC budget day. Local tests cover concurrent admission through two store instances, midnight settlement, invalid amounts, and gateway in-flight admission.

Reservations use UTF-8 prompt bytes plus a framing allowance and configured maximum output tokens with the existing price table. This is a conservative text estimate, not a guaranteed provider billing ceiling. Unknown, legacy or zero-priced hosted models fail closed. Successful responses settle from validated usage before content validation; missing usage or a mismatched returned model keeps the hold and fails without replay. Timeout/network failures retain their holds because billing is unknown, and each retry needs a new reservation. An operator reconciliation workflow is still needed for unresolved holds. Actual charges above the estimate are recorded honestly and can exceed the allowance; provider-side spending controls remain necessary.

Outstanding release work: actual hosted adapter compatibility checks; live Supabase/Postgres migration and cross-connection concurrency validation; operational concurrency and backup restore validation. Existing passing local tests do not establish production readiness. The customer coach currently supplies no premium entitlement and therefore remains local-only until entitlement wiring is implemented and verified.
