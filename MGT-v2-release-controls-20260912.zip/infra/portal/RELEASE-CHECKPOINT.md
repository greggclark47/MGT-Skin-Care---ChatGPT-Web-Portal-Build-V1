# AI release controls checkpoint

Hosted inference now requires an identified account and server-provided premium entitlement on every hosted candidate, including routine-task fallbacks. Budgets are rechecked before each attempt. Accounting or telemetry failures after inference propagate without repeating the provider call.

The admin dashboard converts stored cents into dollars and labels its counts as telemetry records: validation rejections can produce multiple records for one request. These counts are not unique request totals. Token estimates exclude local hardware and hosting costs.

Validated locally: compiled gateway release-control tests, gateway regressions, API build and referral integration tests, and web type checking.

Outstanding release work: atomic budget reservations across concurrent requests; actual hosted adapter compatibility checks; live Supabase/Postgres migration validation; operational concurrency and backup restore validation. Existing passing local tests do not establish production readiness. The customer coach currently supplies no premium entitlement and therefore remains local-only until entitlement wiring is implemented and verified.
