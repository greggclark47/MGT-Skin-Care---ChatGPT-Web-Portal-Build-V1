import assert from 'node:assert/strict';
import {AiGateway} from '../router';
import {InMemoryBudgetStore} from '../budget';
import type {ProviderAdapter} from '../adapters';

async function main(){
 let calls=0;
 const adapter:ProviderAdapter={name:'openai',async complete(config){calls++;return {text:'{"blurb":"Reviewed copy"}',provider:'openai',model:config.model,input_tokens:100,output_tokens:50};}};
 const request={task_type:'product_why' as const,user_id:'account',system_prompt:'s',user_prompt:'u'};
 const gateway=new AiGateway({adapters:{openai:adapter}});
 assert.equal((await gateway.execute(request)).ok,false);
 assert.equal(calls,0,'A free request cannot escalate to hosted inference');
 assert.equal((await gateway.execute({...request,user_id:null,has_premium_entitlement:true})).ok,false);
 assert.equal(calls,0,'Anonymous callers cannot bypass accounting');
 assert.equal((await gateway.execute({...request,has_premium_entitlement:true})).ok,true);
 assert.equal(calls,1);
 const brokenLog=new AiGateway({adapters:{openai:adapter},logSink:{async write(){throw Error('log unavailable');}}});
 await assert.rejects(brokenLog.execute({...request,has_premium_entitlement:true}),/log unavailable/);
 assert.equal(calls,2,'Logging failure must not replay paid inference');
 const brokenBudget=new InMemoryBudgetStore();
 brokenBudget.record=async()=>{throw Error('accounting unavailable');};
 const brokenAccounting=new AiGateway({adapters:{openai:adapter},budgetStore:brokenBudget});
 await assert.rejects(brokenAccounting.execute({...request,has_premium_entitlement:true}),/accounting unavailable/);
 assert.equal(calls,3,'Accounting failure must not replay paid inference');
 console.log('Release controls passed: entitlement, anonymous access, and no accounting/telemetry replay.');
}
main().catch(error=>{console.error(error);process.exitCode=1;});
