const assert=require('node:assert/strict');
const {LocalStore}=require('../dist/portal/store.js');
const {StoreBudgetStore}=require('../dist/portal/ai.js');

(async()=>{
 const store=new LocalStore(':memory:'),first=new StoreBudgetStore(store),second=new StoreBudgetStore(store);
 assert.equal(await first.spentToday('user_1','tier1_copy'),0);
 await first.record('user_1','tier1_copy',1.25);
 await second.record('user_1','tier1_copy',2.75);
 assert.equal(await first.spentToday('user_1','tier1_copy'),4);
 assert.equal(await second.spentToday('user_1','tier3_premium'),0);
 await store.close();console.log('AI budget persistence smoke passed');
})().catch(error=>{console.error(error);process.exitCode=1;});
