'use client';
import React,{useState} from 'react';
import {hub,useHub} from '../../../lib/hub';
import {LoadState} from '../../../components/HubFrames';

export default function AnalysisPage(){
 const admin=useHub('/admin');
 const [question,setQuestion]=useState('');
 const [consent,setConsent]=useState(false);
 const [busy,setBusy]=useState(false);
 const [error,setError]=useState('');
 const [result,setResult]=useState<any>(null);
 const allowed=admin.data?.roles?.some((role:string)=>['superadmin','compliance'].includes(role));
 async function submit(event:React.FormEvent){
  event.preventDefault();setBusy(true);setError('');setResult(null);
  try{setResult(await hub('/admin/ai/analyze',{question,ai_consent:consent}));}
  catch(err){setError((err as Error).message);}
  finally{setBusy(false);}
 }
 return <main><h1 className="app-page-title">Portal AI analysis</h1>
  <p>For authorized operators to review complex portal operations questions. Responses are advisory and do not change the portal.</p>
  <LoadState {...admin} retry={admin.reload}/>
  {admin.data&&!allowed&&<p role="alert" className="notice error">Your account cannot use this tool.</p>}
  {allowed&&<form className="panel stack" onSubmit={submit}>
   <label className="field">Operational question<textarea value={question} onChange={event=>setQuestion(event.target.value)} maxLength={1200} required/></label>
   <p className="muted">Do not include customer details, medical information, passwords, or API keys. Hosted analysis uses your organization’s OpenAI API account and is limited to three requests per day.</p>
   <label className="check-label"><input type="checkbox" checked={consent} onChange={event=>setConsent(event.target.checked)}/> I allow this question to be sent to the configured AI provider.</label>
   <button className="button primary" disabled={busy||!consent}>{busy?'Analyzing…':'Analyze question'}</button>
  </form>}
  {error&&<p role="alert" className="notice error">{error}</p>}
  {result&&<section className="panel" aria-live="polite"><h2>Analysis</h2><p>{result.analysis?.analysis}</p>
   <h3>Risks</h3><ul>{result.analysis?.risks?.map((item:string,index:number)=><li key={index}>{item}</li>)}</ul>
   <h3>Recommendations</h3><ul>{result.analysis?.recommendations?.map((item:string,index:number)=><li key={index}>{item}</li>)}</ul>
   <p className="muted">Model: {result.model} · Estimated token cost: ${(Number(result.cost_cents)/100).toFixed(4)}</p>
  </section>}
 </main>;
}
