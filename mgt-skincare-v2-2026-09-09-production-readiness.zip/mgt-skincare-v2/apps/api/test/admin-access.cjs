const assert=require('node:assert/strict');
const {createPortal}=require('../dist/portal/server');
const {LocalStore}=require('../dist/portal/store');
(async()=>{
 const db=new LocalStore(':memory:');
 const app=await createPortal({store:db,env:{NODE_ENV:'test',DEMO_MODE:'false',PUBLIC_ORIGIN:'http://localhost:3000'},verifyOtp:async email=>({id:email,email})});
 const server=app.listen(0,'127.0.0.1');await new Promise(r=>server.once('listening',r));
 const scopes=['orders','tickets','partners','jobs','audit','deletion_requests'];
 function client(){let cookie='',csrf='';return async(path,body,extra={})=>{
  const res=await fetch('http://127.0.0.1:'+server.address().port+'/api/hub'+path,{method:body===undefined?'GET':'POST',headers:{cookie,origin:'http://localhost:3000','content-type':'application/json','x-csrf-token':csrf,...extra},body:body===undefined?undefined:JSON.stringify(body)});
  if(res.headers.get('set-cookie'))cookie=res.headers.get('set-cookie').split(';')[0];
  const data=await res.json();if(data.csrf)csrf=data.csrf;return {status:res.status,data};
 };}
 try{
  await db.tx(async r=>{for(const scope of scopes)await r.put(scope,'sensitive',{id:'sensitive',private_note:'customer-only-record',replies:[]});await r.put('settings','company',{internal_note:'operator-only-setting'});await r.put('knowledge','article',{id:'article',title:'Reviewable content'});});
  const guest=client();await guest('/session');assert.equal((await guest('/admin')).status,401);
  for(const roles of [[],['viewer'],['catalog_editor'],['sme'],['compliance'],['superadmin'],['sme','compliance']]){
   const email=(roles.join('-')||'customer')+'@example.test';
   await db.tx(r=>r.put('accounts',email,{id:email,email,roles}));
   const c=client();await c('/session');assert.equal((await c('/auth/verify',{email,code:'123456'})).status,200);await c('/session');
   const result=await c('/admin',undefined,{'x-user-id':'forged','x-role':'superadmin'});
   if(!roles.length){assert.equal(result.status,403);continue;}
   const operations=roles.some(r=>['superadmin','compliance'].includes(r));
   assert.equal(result.status,200);assert.equal(result.data.access.operations,operations);
   assert.equal(result.data.knowledge[0].id,'article');
   for(const scope of scopes)assert.equal(result.data[scope].some(x=>x.id==='sensitive'),operations,roles+': '+scope);
   assert.equal(result.data.company!==null,operations);
   if(!operations){assert(!JSON.stringify(result.data).includes('customer-only-record'));assert.equal((await c('/admin/ticket',{id:'sensitive',reply:'no'})).status,403);assert.equal((await c('/admin/readiness')).status,403);}
   if(roles.includes('superadmin')){
    await db.tx(r=>r.put('accounts',email,{id:email,email,roles:['viewer']}));
    const revoked=await c('/admin');assert.equal(revoked.data.access.operations,false);assert.deepEqual(revoked.data.tickets,[]);
   }
  }
  console.log('Admin access checks passed: guest/customer denial, seven role combinations, sensitive record filtering, forged headers, denied writes and immediate role revocation.');
 }finally{await new Promise(r=>server.close(r));await db.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
