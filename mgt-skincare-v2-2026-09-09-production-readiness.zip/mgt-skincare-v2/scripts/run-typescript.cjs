// Run source smoke suites without a separate transpiler daemon. Builds perform type checking.
const fs=require('node:fs');
const path=require('node:path');
const ts=require('../apps/web/node_modules/typescript');
for(const extension of ['.ts','.tsx'])require.extensions[extension]=(module,file)=>{
 const output=ts.transpileModule(fs.readFileSync(file,'utf8'),{fileName:file,compilerOptions:{module:ts.ModuleKind.CommonJS,esModuleInterop:true,target:ts.ScriptTarget.ES2020,jsx:ts.JsxEmit.ReactJSX}}).outputText;
 module._compile(output,file);
};
if(!process.argv[2])throw Error('Supply a smoke suite path');
require(path.resolve(process.argv[2]));
